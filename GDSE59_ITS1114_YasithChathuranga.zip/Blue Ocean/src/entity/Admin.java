package entity;

public class Admin extends User{
    public Admin(String userName, String password) {
        setUserName(userName);
        setPassword(password);
    }
}
