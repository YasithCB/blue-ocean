package entity;

public class Receptionist extends User{
    public Receptionist(String userName, String password) {
        setUserName(userName);
        setPassword(password);
    }
}
